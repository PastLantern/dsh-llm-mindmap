import { test } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { Store } from '../lib/store.js';
import { createWebHandler } from '../lib/web-ui.js';
import { attachmentRoutes } from '../lib/attachments.js';
import { nodeMastery } from '../lib/changes.js';

async function setup() {
  const dir = await mkdtemp(path.join(tmpdir(), 'llm-mindmap-'));
  const store = new Store(dir, { onExportError: error => { throw error; } });
  await store.ready;
  const handler = createWebHandler({ store, extraRoutes: attachmentRoutes(), logError: () => {} });
  const state = await store.read();
  const ctx = { dir, store, vaultId: state.vaultId, revision: state.revision };
  ctx.call = async (method, route, body) => {
    const chunks = body === undefined ? [] : [Buffer.from(JSON.stringify(body))];
    const req = {
      method, url: `/llm-mindmap/api/${route}${route.includes('?') ? '&' : '?'}vaultId=${ctx.vaultId}`,
      headers: { host: '127.0.0.1:3090', ...(body === undefined ? {} : { 'content-type': 'application/json' }) },
      socket: { remoteAddress: '127.0.0.1' },
      async *iterator() { yield* chunks; }, resume() {},
    };
    let status = 0;
    let text = '';
    const res = { headersSent: false, writableEnded: false, writeHead(code) { status = code; this.headersSent = true; }, end(data) { text = String(data ?? ''); this.writableEnded = true; }, on() {}, destroy(error) { throw error; } };
    await handler(req, res);
    const json = JSON.parse(text);
    if (json.nodes) ctx.revision = json.revision;
    return { status, json };
  };
  ctx.write = (method, route, body = {}) => ctx.call(method, route, { ...body, vaultId: ctx.vaultId, expectedRevision: ctx.revision });
  ctx.close = () => rm(dir, { recursive: true, force: true });
  return ctx;
}
const children = (doc, id) => doc.nodes.filter(node => node.parentId === id).map(node => node.id);

test('示例库可以加载，RSI 笔记和复习卡都在', async () => {
  const ctx = await setup();
  try {
    const doc = await ctx.store.read();
    assert.equal(doc.nodes.length, 15);
    assert.ok(doc.problems.some(problem => problem.id === 'prob-rsi-guard'));
    assert.equal(doc.template.cardName, '复习卡');
    assert.equal(nodeMastery(doc, doc.nodes.find(node => node.id === 'node-rsi-notes')), 'weak');
  } finally { await ctx.close(); }
});

test('节点可以插到兄弟节点后面、移动、撤销，不能移进自己的子节点', async () => {
  const ctx = await setup();
  try {
    let r = await ctx.write('POST', 'nodes', { parentId: 'cat-arch', title: '新节点', summary: '', afterId: 'node-gqa' });
    const id = r.json.result.id;
    assert.equal(children(r.json, 'cat-arch')[1], id);
    r = await ctx.write('POST', `nodes/${id}/move`, { parentId: 'cat-post', beforeId: 'node-sft' });
    assert.equal(children(r.json, 'cat-post')[0], id);
    r = await ctx.call('POST', `undo/${r.json.undoToken}`, {});
    assert.ok(children(r.json, 'cat-arch').includes(id));
    r = await ctx.write('POST', 'nodes/cat-agent/move', { parentId: 'node-rsi' });
    assert.equal(r.status, 400);
  } finally { await ctx.close(); }
});

test('删除节点后可以撤销；中间有新改动就不能撤销', async () => {
  const ctx = await setup();
  try {
    let r = await ctx.write('DELETE', 'nodes/node-harness');
    const token = r.json.undoToken;
    r = await ctx.write('PATCH', 'nodes/node-gqa', { title: 'GQA' });
    r = await ctx.call('POST', `undo/${token}`, {});
    assert.equal(r.status, 409);
  } finally { await ctx.close(); }
});

test('新的一节可以插在指定位置，也可以调整顺序', async () => {
  const ctx = await setup();
  try {
    let r = await ctx.write('POST', 'nodes/node-rsi-notes/blocks', { title: '插入', tag: '工程实践', content: 'x', afterId: 'overview' });
    const id = r.json.result.id;
    let blocks = r.json.nodes.find(node => node.id === 'node-rsi-notes').note.blocks;
    assert.equal(blocks[0].id, id);
    r = await ctx.write('POST', `nodes/node-rsi-notes/blocks/${id}/move`, { toIndex: 2 });
    blocks = r.json.nodes.find(node => node.id === 'node-rsi-notes').note.blocks;
    assert.equal(blocks[2].id, id);
  } finally { await ctx.close(); }
});

test('复习打分会更新掌握度和下次复习日期', async () => {
  const ctx = await setup();
  try {
    const r = await ctx.write('POST', 'problems/prob-rsi-guard/review', { rating: 'hard' });
    const card = r.json.problems.find(problem => problem.id === 'prob-rsi-guard');
    assert.equal(card.mastery, 'assisted');
    assert.match(card.due, /^\d{4}-\d{2}-\d{2}$/);
  } finally { await ctx.close(); }
});

test('升格一节后，指向它的引用改为指向新的子节点', async () => {
  const ctx = await setup();
  try {
    const r = await ctx.write('POST', 'nodes/node-rsi-notes/blocks/nb-rsi-loop/promote', { targetTitle: '主循环' });
    const child = r.json.result.id;
    const guard = r.json.nodes.find(node => node.id === 'node-rsi-notes').note.blocks.find(block => block.id === 'nb-rsi-guard');
    assert.ok(guard.content.includes(`[[${child}#overview>主循环]]`));
  } finally { await ctx.close(); }
});

test('双链 Markdown 按小节编号，引用转成标题链接', async () => {
  const ctx = await setup();
  try {
    const r = await ctx.call('GET', 'markdown');
    const page = r.json.files['nodes/node-rsi-notes.md'];
    assert.ok(page.includes('## 1 核心框架'));
    assert.ok(!page.includes('[[#'));
    assert.ok(page.includes('[[nodes/node-rsi-notes#五条护栏|§'));
  } finally { await ctx.close(); }
});

test('Agent 提议插在指定一节后面，收录时可以先改', async () => {
  const ctx = await setup();
  try {
    let r = await ctx.write('POST', 'proposals', { kind: 'append_note_block', payload: { nodeId: 'node-rsi-notes', blockTitle: '提议', tag: '工程实践', content: 'y', afterBlockId: 'overview', rationale: '测试' } });
    r = await ctx.write('POST', `proposals/${r.json.result.id}/accept`, { edits: { blockTitle: '改过的' } });
    assert.equal(r.json.nodes.find(node => node.id === 'node-rsi-notes').note.blocks[0].title, '改过的');
  } finally { await ctx.close(); }
});

test('删除讨论会删掉同一句话的全部轮次，可以撤销', async () => {
  const ctx = await setup();
  try {
    const doc = await ctx.store.read();
    const quoted = doc.anchoredThreads.find(thread => thread.quote);
    let r = await ctx.write('DELETE', `threads/${quoted.id}`);
    assert.ok(!r.json.anchoredThreads.some(thread => thread.quote?.id === quoted.quote.id));
    r = await ctx.call('POST', `undo/${r.json.undoToken}`, {});
    assert.ok(r.json.anchoredThreads.some(thread => thread.id === quoted.id));
  } finally { await ctx.close(); }
});

test('父笔记在 Markdown 里列出下级笔记', async () => {
  const ctx = await setup();
  try {
    const r = await ctx.call('GET', 'markdown');
    assert.ok(r.json.files['nodes/cat-arch.md'].includes('## 下级笔记'));
  } finally { await ctx.close(); }
});

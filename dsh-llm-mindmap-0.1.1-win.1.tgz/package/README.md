# DeepSeek Harness 伴学导图（Windows）

伴学导图是 DeepSeek Harness 的插件：一张可编辑的知识导图，每个节点是一篇按节编号的笔记，可以划词单独追问，Agent 的改动先进待审、你确认后才写入，还带按到期日排的复习。数据存在本地，并同步成 Obsidian 双链 Markdown。

全新工作区会带两个示例库：「大模型知识库」（15 个节点，其中「RSI 递归自我改进」是一份完整的示例笔记）和「算法面试刷题库」。

## 需要什么

- Windows 和 Node.js 22 或更高版本（`node -v` 查看）。
- 已安装 DeepSeek Harness 命令行工具 `dsh`。

## 安装到 Harness

假设插件包在「下载」文件夹里。

**方式一：在 Harness 网页里装**

打开「插件」→「添加插件」，在「包名或地址」里粘贴：

```
C:/Users/你的用户名/Downloads/dsh-llm-mindmap-0.1.1-win.1.tgz
```

点「安装」，完成后点「立即启用」。如果提示重启，重启当前 profile。

**方式二：用终端装**

```powershell
$bundle = Join-Path $HOME 'Downloads/dsh-llm-mindmap-0.1.1-win.1.tgz'
dsh.cmd plugin --profile web add ($bundle -replace '\\', '/')
dsh.cmd --profile web --no-open
```

如果命令行提供的是 `dsh.exe`，把 `dsh.cmd` 换成 `dsh.exe`。用本地源码构建的 CLI 时，在 Harness 源码目录里运行下面的命令，沿用上面设置好的 `$bundle`。

```powershell
node apps/cli/lib/bin.js plugin --profile web add ($bundle -replace '\\', '/')
node apps/cli/lib/bin.js --profile web --no-open
```

如果装过伴学导图，先在「插件」里移除原安装，再添加当前安装包。已有导图数据保存在工作区的 `.llm-mindmap/`。

## 在会话里用

1. 用启动器给出的链接登录 Harness。打开导图有两个入口：右侧栏的「+」菜单里选「伴学导图」，或者点会话顶栏右侧的导图图标（有待审提案时旁边显示数量）。导图在右侧栏里只有一份，换会话时不会重新加载，停在原来的位置。侧栏导图右上角可以在新的浏览器标签里全屏打开。
2. 点导图里的节点打开笔记。笔记按节编号：1 是核心框架，后面每一节依次是 2、3、4…，节里的小标题是 2.1、2.2。
3. 在正文里选中一句话，点「追问这句」，在弹出的小输入框里写下第一个问题，按回车。插件会建一个追问会话，Harness 主对话区自动跳过去，回答在那里显示；这时那句话才会高亮。追问会话只带这句话和所在小节作为上下文，能读导图和论文小节，但不能改导图。值得留下的回答，点它下面的「存到导图」，在侧栏里改好提交到待审。追问会话顶栏有「回到原会话」。再点那句高亮会回到同一个追问会话；鼠标悬停能看到最近的一问一答，也能重开一轮或删除。
4. 主会话里每条回答下面也有「存到导图」，草稿里可以选「直接写入笔记」或「放进待审」。回答里小标题自带的编号（如「5.」「2.1」）会自动去掉，统一用笔记的编号。侧栏里打开的那篇笔记会作为主会话的参考（只带标题和各节目录），可以直接问「§2.1 再讲一下」。Agent 也可以调用导图工具提出改动，聊天里会出现提案卡片，可以直接收录，也可以到「待审」里先改再收。
5. 「复习」里按到期日出卡片，先回忆再看答案，按 1 / 2 / 3 打分。有卡片的节点，掌握度由卡片汇总。

Windows 上可用 `Ctrl+K` 打开搜索，编辑笔记时用 `Ctrl+Enter` 保存。先点一下导图，再用 Tab 加子节点、Enter 加同级、方向键移动选中。可以拖动节点换位置，或右键打开节点菜单。全部快捷键在右上角「⋯ → 快捷键」。

## 不装 Harness，单独预览

独立模式可以查看和编辑导图、笔记。模型追问在 Harness 中使用。用 PowerShell 解压并启动本地预览。

```powershell
$bundle = Join-Path $HOME 'Downloads/dsh-llm-mindmap-0.1.1-win.1.tgz'
$preview = New-Item -ItemType Directory -Path '.\mindmap-preview' -ErrorAction Stop
tar.exe -xzf $bundle -C $preview.FullName
if ($LASTEXITCODE -ne 0) { throw '插件包解压失败' }
Set-Location -LiteralPath (Join-Path $preview.FullName 'package')
npm.cmd install --omit=dev
npm.cmd start
```

然后在浏览器打开 <http://127.0.0.1:3090/llm-mindmap>。数据保存在当前目录的 `.llm-mindmap/` 里。要换端口，先停止服务，在 PowerShell 中执行 `$env:MINDMAP_PORT = '3091'`，再执行 `npm.cmd start`。

## 本地数据

- `.llm-mindmap/vaults.json` 是知识库列表；每个知识库的 `vaults/<id>/mindmap.v2.json` 是权威数据。
- 每个知识库的 `markdown/` 里有 `INDEX.md`、`nodes/` 节点页和 `problems/` 卡片页，每次改动自动同步，可以直接用 Obsidian 打开这个文件夹。笔记按节编号，小节引用会转成 Obsidian 的标题链接。
- `assets/` 保存上传的 PDF 和图片。打开 PDF 目录时在本地生成 `pdf-cache/`，需要可选依赖 `pdfjs-dist`（`npm install` 会自动装）。整篇拆解成提案需要从 Harness 打开。
- `.md`、`.xmind`、`.mm` 导图可以预览后挂到某个节点下，或者新建一个知识库。

## 小节引用

在编辑框里点「插入小节引用」，或者在任意一节的 ⋯ 菜单里点「复制引用」再粘贴。正文里存的是 `[[节点ID#笔记块ID]]` 这样的写法，显示成可点击的「§3.1 标题」。插入、删除或调整小节顺序后，编号会自动更新；被删掉的小节显示为「失效引用」。

## 验收

在已安装依赖的解包目录里运行。

```powershell
npm.cmd test
```

测试会在临时目录里启动插件的存储和网页接口，覆盖节点移动和撤销、插入小节、复习排期、升格时的引用迁移、Markdown 导出等。

## 侧栏导图一片空白

插件会先试着把一份导图盖在右侧栏上（换会话时不重新加载）；如果检测到被挡住或定位不到侧栏，会自动改成直接嵌入侧栏，浏览器 Console 里会出现一行 `[dsh-llm-mindmap] 侧栏导图改为直接嵌入：…`。

想直接用嵌入方式，在 Harness 页面的 Console 里执行下面这行再刷新：

```js
localStorage.setItem('llm-mindmap:seat', 'inline')
```

改回来：`localStorage.removeItem('llm-mindmap:seat')`。
